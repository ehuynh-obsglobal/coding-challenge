## Bug #2: Cannot Open Project Modal

### Reproduction Steps
1. Navigate to the **My Projects** section.
2. Click on any project card.

**Expected**  
A modal displays with the selected project's details.

**Actual**  
No modal is displayed.