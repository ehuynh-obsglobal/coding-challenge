## Bug #1: Projects are not loading.

### Reproduction Steps
1. Load the page.

**Expected**  
The Projects section is populated with project cards.

**Actual**  
No project cards are displayed.